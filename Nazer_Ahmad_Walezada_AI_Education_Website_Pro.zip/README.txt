AI IN EDUCATION — WEBSITE
Created for: Nazer Ahmad Walezada
Year: 2026

Files:
- index.html
- style.css
- script.js

How to use:
1. Extract the ZIP.
2. Open index.html in a browser.
3. The site uses online Unsplash images and Google Fonts, so an internet connection is needed for the remote images/fonts.

GitHub Pages:
Upload the three files to a GitHub repository and enable GitHub Pages from Settings > Pages.
